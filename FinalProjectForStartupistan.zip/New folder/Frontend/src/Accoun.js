import React from "react";

export default function Account() {
  return (
    <div>
      <h1 className="text-center">Free Component</h1>
    </div>
  );
}