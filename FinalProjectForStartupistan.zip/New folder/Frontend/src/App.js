
import './style.css'
import './scss/bootstrap.scss'
import {
  Outlet,
  createBrowserRouter,
  RouterProvider,
  Routes,
  Route,
  BrowserRouter,
  Router, 
  Navigate
} from "react-router-dom"
import Home from './pages/Home';
import Topbar from './components/Topbar/Navbar'
import Footer from './components/Footer/Footer'
// import Header from './components/Header/Header'
import Contact from './pages/Contact'
import About from './pages/About'
import Testmonial from './pages/Testmonial'
import Courses from './pages/Courses'
import Exam from './pages/Sidebar'
import { Row, Col } from "react-bootstrap";
import Team from './pages/Team';
import Admin from './pages/admin/Admin';
import UpdateStudent from './pages/admin/student/UpdateStudent';
import StudentData from './pages/admin/student/StudentData';
import AddStudent from './pages/admin/student/AddStudent';
import EmpData from './pages/admin/Employees/EmpData';
import AddEmp from './pages/admin/Employees/AddEmp';
import UpdateEmp from './pages/admin/Employees/UpdateEmp';
import CourseData from './pages/admin/Course/CourseData';
import AddCourse from './pages/admin/Course/AddCourse';
import UpdateCourse from './pages/admin/Course/UpdateCourse';
import ContactData from './pages/admin/Contact/ContactData';
import UpdateContact from './pages/admin/Contact/UpdateContact';
import AddContact from './pages/admin/Contact/AddContact';
import TeamData from './pages/admin/Team/TeamData';
import AddTeam from './pages/admin/Team/AddTeam';
import UpdateTeam from './pages/admin/Team/UpdateTeam';
import TestmonialData from './pages/admin/Testmonial/TestmonialData';
import UpdateTestmonial from './pages/admin/Testmonial/UpdateTestmonial';
import AddTestmonial from './pages/admin/Testmonial/AddTestmonial';
import AboutData from './pages/admin/About/AboutData';
import UpdateAbout from './pages/admin/About/UpdateAbout';
import AddAbout from './pages/admin/About/AddAbout';
import Login from './pages/admin/login';
import Register from './pages/admin/register';
import SinglePage from './pages/DescriptionPage/SingelPage';
import CoursePage from './pages/DescriptionPage/CoursePage';
import FreeComponent from './FreeComponent';
import AuthComponent from './AuthComponent';
import Account from './Accoun';
import ProtectedPage from './ProtectedRoutes';
import Image from './image';

const Layout = ()=>{
  return(<div>
    <Topbar/>
    <Outlet/>
    <Footer/>
  </div>)
}
const Sidebar = ()=>{
  return(
  <div className='row over' style={{overflowX:'hidden'}}>
  <div className='col-md-3' >
    <Exam/>
  </div>
 <div className='col-md-8'>
 <Outlet/>
  </div>
  </div>)
}

const router = createBrowserRouter([

  {
    path: "/",
    element: <Layout/>,
    children: [
      {path: '/', 
       element: <Home/>},
      {
        path: "/contact",
        element: <Contact/>
      },
      {
        path: "/coursepage",
        element: <CoursePage/>
      },
      {
        path: "/singlepage",
        element: <SinglePage/>
      },
    
      {
        path: '/about',
        element: <About/>
      },
      {
        path: "/testimonial",
        element: <Testmonial/>
      },
      {
        path: "/team",
        element: <Team/>
      },
      {
        path: "/courses",
        element: <Courses/>
      },
    ],
    
  },
  { 
    path: "/",
    element: <Sidebar/>,    
    children: [
      {
      path:'/controlhome',
      element:<Admin/>
      },
      {
        path: "/studentdata",
        element: <StudentData/>
      },
      {
        path: "/updateStudent",
        element:<UpdateStudent/>
      },
      {
        path: "/addstudent",
        element: <AddStudent/>
      },
      {
        path: "/addemp",
        element: <AddEmp/>
      },
      {
        path: "/updateemp",
        element: <UpdateEmp/>
      },
      {
        path: "/empdata",
        element: <EmpData/>
      },
      {
        path: "/coursedata",
        element: <CourseData/>
      },
      {
        path: "/updatecourse",
        element: <UpdateCourse/>
      },
      {
        path: "/addcourse",
        element: <AddCourse/>
      },
      {
        path: "/contactdata",
        element: <ContactData/>
      },
      {
        path: "/updatecontact",
        element: <UpdateContact/>
      },
      {
        path: "/addcontact",
        element: <AddContact/>
      },
      {
        path: "/teamdata",
        element: <TeamData/>
      },
      {
        path: "/addteam",
        element: <AddTeam/>
      },
      {
        path: "/updateteam",
        element: <UpdateTeam/>
      },
      {
        path: "/updatetestmonial",
        element: <UpdateTestmonial/>
      },
      {
        path: "/addtestmonial",
        element: <AddTestmonial/>
      },
      {
        path: "/testmonialdata",
        element: <TestmonialData/>
      },
      {
        path: "/aboutdata",
        element: <AboutData/>
      },
      {
        path: "/addabout",
        element: <AddAbout/>
      },
      {
        path: "/updateabout",
        element: <UpdateAbout/>
      },

  ]},
  {
    path: "/image",
    element: <Image/>
  },
  {
    path: "/admin",
    element: <Login/>
  },
],
)

export default function App({login}){
  return(
    <div className='app'>
      <RouterProvider router={router}/>
    </div>
  )};

