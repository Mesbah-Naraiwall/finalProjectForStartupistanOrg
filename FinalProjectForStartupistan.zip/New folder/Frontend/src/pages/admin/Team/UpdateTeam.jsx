import React, { useState, useEffect } from "react";
import axios from "axios";
import { useLocation, useNavigate, useParams } from "react-router-dom";

// ==================================contact data================
export default function UpdateTeam(userId){
const [nameOfInstructor, setNameOfInstructor] = useState('');
const [field,setField] = useState('');
const { _id } = useParams();

const state = useLocation().state;



const navigate = useNavigate();
// ==================================get data ================

useEffect(() => {
    getTeamById();
  }, []);

// ===========================================UPDATE data =========================
const getTeamById = async () => {
    const response = await axios.get(`http://localhost:4000/instructor/${state._id}`);
    setNameOfInstructor(response.data.nameOfInstructor);
    setField(response.data.field);
  };
// ===========================
const updateTeam = async (e) => {
    e.preventDefault();
    try {
      await axios.patch(`http://localhost:4000/instructor/${state._id}`, {
        nameOfInstructor,
        field,
      });
      navigate("/teamdata");
    } catch (error) {
      console.log(error);
    }
  };
  return(
  <div className="container">
    <h1>Update Instructor</h1>
    <form onSubmit={updateTeam}>
    <div className="form-group">
            <label for="nameOfInstructor">Office</label>
            <input type="text" 
            class="form-control"
            value={nameOfInstructor}
            id="nameOfInstructor" 
            placeholder="nameOfInstructor"
            onChange={(e) => setNameOfInstructor(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="field">Field</label>
            <input type="text" 
            class="form-control"
            value={field}
            id="field" 
             placeholder="Field"
            onChange={(e) =>setField(e.target.value)}
            />
        </div>
     {/* ==================== */}
        <button type="submit" class="btn btn-success">Edit</button>
        </form>
  </div>
)}