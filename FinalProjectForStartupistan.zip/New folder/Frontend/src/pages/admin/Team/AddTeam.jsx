import React, { useState, useEffect } from "react";
import axios from "axios";
import { useLocation, useNavigate, useParams } from "react-router-dom";
// import EmployeeData from './EmployeeData'
import moment from "moment";

// ==================================student data================
export default function AddEmp(){
const [nameOfInstructor, setNameOfInstructor] = useState('');
const [field, setField] = useState('');

const navigate = useNavigate();

// ===========================================add data =========================
const saveTeam = async (e) => {
    e.preventDefault();
    try{
    await axios.post(`http://localhost:4000/instructor`,
    {
        nameOfInstructor,
        field,
    });
    navigate("/teamdata");
    } catch(error){
        console.log(error);
    }
  };
// ===========================
  return(
  <div className="container">
    <h1>Add Instructor</h1>
    <form onSubmit={saveTeam}>
    <div className="form-group">
            <label for="nameOfInstructor">Office</label>
            <input type="text" 
            class="form-control"
            value={nameOfInstructor}
            id="nameOfInstructor" 
            placeholder="nameOfInstructor"
            onChange={(e) => setNameOfInstructor(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="field">field</label>
            <input type="text" 
            class="form-control"
            value={field}
            id="field" 
             placeholder="Name"
            onChange={(e) => setField(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <button type="submit" class="btn btn-primary">Add</button>
        </form>
  </div>
)}