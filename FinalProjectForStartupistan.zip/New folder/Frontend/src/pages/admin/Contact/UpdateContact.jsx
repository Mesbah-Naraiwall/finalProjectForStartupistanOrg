import React, { useState, useEffect } from "react";
import axios from "axios";
import { useLocation, useNavigate, useParams } from "react-router-dom";

// ==================================contact data================
export default function UpdateEmp(userId){
const [office, setoffice] = useState('');
const [mobile, setMobile] = useState('');
const [email, setEmail] = useState('');
const [googleMap, setGoogleMap] = useState('');
const { _id } = useParams();

const state = useLocation().state;



const navigate = useNavigate();
// ==================================get data ================

useEffect(() => {
    getEmpById();
  }, []);

// ===========================================UPDATE data =========================
const getEmpById = async () => {
    const response = await axios.get(`http://localhost:4000/contactinfo/${state._id}`);

    setoffice(response.data.office);
    setMobile(response.data.mobile);
    setEmail(response.data.email);
    googleMap(response.data.googleMap);
  };
// ===========================
const updateContact = async (e) => {
    e.preventDefault();
    try {
      await axios.patch(`http://localhost:4000/contactinfo/${state._id}`, {
        office,
        mobile,
        email,
        googleMap,
      });
      navigate("/contactdata");
    } catch (error) {
      console.log(error);
    }
  };
  return(
  <div className="container">
    <h1>Update Contact</h1>
    <form onSubmit={updateContact}>
    <div className="form-group">
            <label for="office">Office</label>
            <input type="text" 
            class="form-control"
            value={office}
            id="office" 
            placeholder="office"
            onChange={(e) => setoffice(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="mobile">mobile</label>
            <input type="text" 
            class="form-control"
            value={mobile}
            id="mobile" 
             placeholder="Name"
            onChange={(e) => setMobile(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="email">Email</label>
            <input type="email" 
            class="form-control"
            value={email}
            id="email" 
            placeholder="Email"
            onChange={(e) => setEmail(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="googleMap">Google Map</label>
            <input type="text" 
            class="form-control"
            value={googleMap}
            id="googleMap" 
            placeholder="googleMap"
            onChange={(e) => setGoogleMap(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <button type="submit" class="btn btn-success">Edit</button>
        </form>
  </div>
)}