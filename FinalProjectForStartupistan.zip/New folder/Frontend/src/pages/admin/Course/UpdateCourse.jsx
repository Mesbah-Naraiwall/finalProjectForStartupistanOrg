import React, { useState, useEffect } from "react";
import axios from "axios";
import { useLocation, useNavigate, useParams } from "react-router-dom";

// ==================================employee data================
export default function UpdateEmp(userId){
const [nameOfCourse, setNameOfCourse] = useState('');
const [instructor, setInstructor] = useState('');
const [rating, setRating] = useState('');
const [desc, setDesc] = useState('');
const [hours, setHours] = useState('');
const [studentMembers, setStudentMembers] = useState('');
const [price, setPrice] = useState('');
const [image, setImage] = useState('');
const [status, setStatus] = useState('')


const { _id } = useParams();

const state = useLocation().state;


const navigate = useNavigate();
// ==================================get data ================

useEffect(() => {
    getCourseById();
  }, []);

// ===========================================UPDATE data =========================
const getCourseById = async () => {
    const response = await axios.get(`http://localhost:4000/popularcourse/${state._id}`);

    setNameOfCourse(response.data.nameOfCourse);
    setInstructor(response.data.instructor);
    setRating(response.data.rating);
    setDesc(response.data.desc);
    setHours(response.data.hours);
    setStudentMembers(response.data.studentMembers);
    setPrice(response.data.price);
    setPrice(response.data.image);

  };
// ===========================
const updateCourse = async (e) => {
    e.preventDefault();
    try {
      await axios.patch(`http://localhost:4000/popularcourse/${state._id}`, {
        nameOfCourse,
        instructor,
        rating,
        studentMembers,
        desc,
        hours,
        price,
        image
      });
      navigate("/coursedata");
    } catch (error) {
      console.log(error);
    }
  };


  return(
  <div className="container">
    <h1>Update Course</h1>
    <form onSubmit={updateCourse}>
    <div className="form-group">
            <label for="nameOfCourse">Name Of Course</label>
            <input type="text" 
            class="form-control"
            id="nameOfCourse" 
            value={nameOfCourse}
            placeholder="Name Of Course"
            onChange={(e) => setNameOfCourse(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="instructor">Instructor</label>
            <input type="text" 
            class="form-control"
            value={instructor}
            id="instructor" 
             placeholder="instructor"
            onChange={(e) => setInstructor(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="Rating">Rating</label>
            <input type="number" 
            class="form-control"
            id="Rating" 
            value={rating}
            placeholder="Rating"
            onChange={(e) => setRating(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="Price">Price</label>
            <input type="decimal" 
            class="form-control"
            value={price}
            id="Price" 
            placeholder="Price"
            onChange={(e) => setPrice(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="hours">Hours</label>
            <input type="number" 
            class="form-control"
            id="hours" 
            value={hours}
            placeholder="Hours"
            onChange={(e) => setHours(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="Description">Course Description</label>
            <input type="text" 
            class="form-control"
            id="Description" 
            value={desc}
            placeholder="Course Description"
            onChange={(e) => setDesc(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="studentMembers">Student Members</label>
            <input type="number" 
            class="form-control"
            id="studentMembers" 
            value={studentMembers}
            placeholder="studentMembers"
            onChange={(e) => setStudentMembers(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="Image">Image</label>
            <input type="file" 
            class="form-control"
            id="Image" 
            value={image}
            placeholder="Image"
            onChange={(e) => setImage(e.target.value)}
            />
        </div>

        {/* ============================= */}

        <button type="submit" class="btn btn-success">Edit</button>
        </form>
  </div>
)}