import React from 'react'
import { Form, Button } from "react-bootstrap";
import { useState, useEffect, useLocation } from "react";
import axios from "axios";

export default function Register() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [register, setRegister] = useState(false);

  // set configurations
  const configuration = {
    method: "post",
    url: "http://localhost:4000/register",
    data: {
      email,
      password,
    },
  };

  axios(configuration)
  .then((result) => {console.log(result);})
  .catch((error) => {console.log(error);})
  
  const handleSubmit = (e) => {
    // prevent the form from refreshing the whole page
    e.preventDefault();
    // make a popup alert showing the "submitted" text
    alert("Submited");
  }
    return (
        <>
            <h2>Register</h2>
    
            <Form onSubmit={(e)=>handleSubmit(e)}>
        {/* email */}
        <Form.Group controlId="formBasicEmail">
          <Form.Label>Email address</Form.Label>
          <Form.Control
            type="email"
            name="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Enter email"
          />
        </Form.Group>

        {/* password */}
        <Form.Group controlId="formBasicPassword">
          <Form.Label>Password</Form.Label>
          <Form.Control
            type="password"
            name="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Password"
          />
        </Form.Group>

        {/* submit button */}
        <Button
          variant="primary"
          type="submit"
          onClick={(e) => handleSubmit(e)}
        >
          Register
        </Button>
      </Form>
        </>
    )
}


// import React, { useState } from 'react'
// import { Link, useNavigate } from 'react-router-dom'
// import axios from 'axios'


// export default function Register(){

//   const [email, setEmail] = useState('');
//   const [password, setPassword] = useState('');

//   const navigate = useNavigate()


// const createUser = async (e) => {
//   e.preventDefault();
//   try{
//   await axios.post(`http://localhost:4000/register`,
//   {
//       email,
//       password,
//   });
//   navigate("/login");
//   } catch(error){
//       console.log(error);
//   }
// };

// <div className="container">
// <h1>Sign Up</h1>
// <form onSubmit={createUser}>
// <div className="form-group">
//         <label for="email">Email</label>
//         <input type="email" 
//         class="form-control"
//         value={email}
//         id="email" 
//         placeholder="email"
//         onChange={(e) => setEmail(e.target.value)}
//         />
//     </div>
//     {/* ============================= */}
//     <div className="form-group">
//         <label for="password">password</label>
//         <input type="text" 
//         class="form-control"
//         value={password}
//         id="password" 
//          placeholder="Name"
//         onChange={(e) => setPassword(e.target.value)}
//         />
//     </div>
//     {/* ============================= */}
//     <button type="submit" class="btn btn-primary">Add</button>
//     </form>
// </div>
// }

// // import React from "react";
// // import pic from '../../pages/course-2.jpg';
// // import { useState, useEffect } from "react";
// // import axios from "axios";
// // import {Link, useNavigate, useParams } from "react-router-dom";

// // export default function Register(){
// //     return(
// //         <form class="form-signin">
// //         <img class="mb-4" src={pic} alt="" width="72" height="72"/>
// //         <h1 class="h3 mb-3 font-weight-normal">Please sign up</h1>
// //         <label for="inputEmail" class="sr-only">Email address</label>
// //         <input type="email" id="inputEmail" class="form-control" placeholder="Email address" required autofocus/>
// //         <label for="inputEmail" class="sr-only"> Username</label>
// //         <input type="email" id="inputEmail" class="form-control" placeholder="Email address" required autofocus/>
// //         <label for="inputPassword" class="sr-only">Password</label>
// //         <input type="password" id="inputPassword" class="form-control" placeholder="Password" required/>
// //         <button class="btn btn-lg btn-primary btn-block" type="submit">Sign up</button>
// //       </form>
// //     )}

// // import React , {useState} from 'react'
// // import axios from "axios";
// // const Register = () => {
// //     const [user,setUser] = useState({
// //         email:"",
// //         password: ""
// //     })
// //     const handleChange = e =>{
// //     setUser({
// //     ...user,//spread operator 
// //     })
// //     }
// // //register function 
// //    const egister = ()=>{
// //    const {email,password} = user
// //    if (email && password){
// //     axios.post("http://localhost:4000/login",user )
// //     .then(res=>console.log(res))
// //    }
// //    else{
// //        alert("invalid input")
// //    };
// //     return (
// //         <>    
// // <div class="flex flex-col max-w-md px-4 py-8 bg-white rounded-lg shadow dark:bg-gray-800 sm:px-6 md:px-8 lg:px-10">
// //     <div class="self-center mb-2 text-xl font-light text-gray-800 sm:text-2xl dark:text-white">
// //         Create a new account
// //     </div>
// //     <span class="justify-center text-sm text-center text-gray-500 flex-items-center dark:text-gray-400">
// //         Already have an account ?
// //         <a href="#" target="_blank" class="text-sm text-blue-500 underline hover:text-blue-700">
// //             Sign in
// //         </a>
// //     </span>
// //     <div class="p-6 mt-8">
// //         <form action="#">
// //             <div class="flex flex-col mb-2">
// //                 <div class=" relative ">
// //                     <input type="text" id="create-account-pseudo" class=" rounded-lg border-transparent flex-1 appearance-none border border-gray-300 w-full py-2 px-4 bg-white text-gray-700 placeholder-gray-400 shadow-sm text-base focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent" name="name" value={user.name} onChange={handleChange} placeholder="FullName"/>
// //                     </div>
// //                 </div>
// //                 <div class="flex gap-4 mb-2">
// //                     <div class=" relative ">
// //                         <input type="text" id="create-account-first-name" class=" rounded-lg border-transparent flex-1 appearance-none border border-gray-300 w-full py-2 px-4 bg-white text-gray-700 placeholder-gray-400 shadow-sm text-base focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent" name="email" value={user.email} onChange={handleChange} placeholder="Email"/>
// //                         </div>

// //                         </div>
// //                         <div class="flex flex-col mb-2">
// //                             <div class=" relative ">
// //                                 <input type="password" id="create-account-email" class=" rounded-lg border-transparent flex-1 appearance-none border border-gray-300 w-full py-2 px-4 bg-white text-gray-700 placeholder-gray-400 shadow-sm text-base focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent" name="password" value={user.password} onChange={handleChange}    placeholder="password"/>
// //                                 </div>
// //                             </div>
// //                             <div class="flex w-full my-4">
// //                                 <button type="submit" class="py-2 px-4  bg-purple-600 hover:bg-purple-700 focus:ring-purple-500 focus:ring-offset-purple-200 text-white w-full transition ease-in duration-200 text-center text-base font-semibold shadow-md focus:outline-none focus:ring-2 focus:ring-offset-2  rounded-lg " onClick={egister} >
// //                                     Register
// //                                 </button>
// //                             </div>
// //                         </form>
// //               </div>
// //             </div>

// //         </>
// //     )
// // }
// // }
// // export default Register
