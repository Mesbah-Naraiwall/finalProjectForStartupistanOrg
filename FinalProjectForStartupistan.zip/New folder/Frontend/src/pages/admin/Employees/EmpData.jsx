import React from "react";
import { useState, useEffect } from "react";
import axios from "axios";
import {Link, useNavigate, useParams } from "react-router-dom";
import moment from 'moment'


export default function EmpData(){
    // ==================================get data ================

  const [loading, setLoading] = useState(true);
  const [data, setData] = useState([])

// ==================================get data ================
    useEffect(() => {
      fetchData();
    }, []);
    // ==================================get data ================
    const fetchData = async () =>{
      setLoading(true);
      try {
        const {data: response} = await axios.get('http://localhost:4000/employee');
        setData(response);
        console.log(data);
      } catch (error) {
        console.error(error.message);
      }
      setLoading(false);
    }
// ===========================================delete data =========================
  const deleteUser = async (id) => {
    try {
      await axios.delete(`http://localhost:4000/employee/${id}`);
      fetchData();
    } catch (error) {
      console.log(error);
    }
  };

    return(
        <div className="table-responsive">
        <h1>Employess Table</h1>
            <table class="table table-hover">
                <thead>
                <tr>
                    <th>Employee Id</th>
                    <th>Name</th>
                    <th>Position</th>
                    <th>Education</th>
                    <th>Joining Date</th>
                    <th>Contract Duration</th>
                    <th>Porject</th>
                    <th>Program</th>
                    <th></th>
                </tr>
                </thead>
        {data.map(item => (<tbody>
            <tr>
            <td>{item.employeeId}</td>
            <td>{item.name}</td>
            <td>{item.position}</td>
            <td>{item.education}</td>
            <td>{moment(item.joiningDate).format("MMM Do YY")}</td>
            <td>{item.contractDuration}</td>
            <td>{item.project}</td>
            <td>
                <Link to={`/updateemp/`} state={item}   >
                
                <button className="btn btn-info" >Edit</button>
                </Link>
                </td>
            <td><button onClick={() => deleteUser(item._id)} className="btn btn-danger">Delete</button></td>
            </tr>
        </tbody>
        ))}
            <Link className="btn btn-success" to="/addemp">Add Employee</Link>
            </table>
        </div>
      )}