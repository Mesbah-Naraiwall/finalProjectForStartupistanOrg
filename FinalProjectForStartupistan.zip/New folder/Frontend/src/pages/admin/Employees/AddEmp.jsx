import React, { useState, useEffect } from "react";
import axios from "axios";
import { useLocation, useNavigate, useParams } from "react-router-dom";
// import EmployeeData from './EmployeeData'
import moment from "moment";

// ==================================student data================
export default function AddEmp(){
const [employeeId, setEmployeeId] = useState('');
const [name, setName] = useState('');
const [position, setPosition] = useState('');
const [joiningDate, setJoiningDate] = useState('');
const [contractDuration, setContractDuration] = useState('');
const [project, setProject] = useState('');
const [education, setEducation] = useState('');


const navigate = useNavigate();

// ===========================================add data =========================
const saveEmp = async (e) => {
    e.preventDefault();
    try{
    await axios.post(`http://localhost:4000/employee`,
    {
        employeeId,
        name,
        position,
        education,
        joiningDate,
        contractDuration,
        project,
    });
    navigate("/empdata");
    } catch(error){
        console.log(error);
    }
  };
// ===========================
  return(
  <div className="container">
    <h1>Add Employee</h1>
    <form onSubmit={saveEmp}>
    <div className="form-group">
            <label for="aid">Employee ID</label>
            <input type="text" 
            class="form-control"
            id="sid" 
            value={employeeId}
            placeholder="Employee ID"
            onChange={(e) => setEmployeeId(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="name">Name</label>
            <input type="text" 
            class="form-control"
            value={name}
            id="name" 
             placeholder="Name"
            onChange={(e) => setName(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="Position">Position</label>
            <input type="text" 
            class="form-control"
            id="Position" 
            value={position}
            placeholder="Position"
            onChange={(e) => setPosition(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="Education">Education</label>
            <input type="text" 
            class="form-control"
            value={education}
            id="Education" 
            placeholder="Education"
            onChange={(e) => setEducation(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="contractDuration">Contract Duration</label>
            <input type="text" 
            class="form-control"
            id="contractDuration" 
            value={contractDuration}
            placeholder="Contract Duration"
            onChange={(e) => setContractDuration(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="JoiningDate">Joining Date</label>
            <input type="date" 
            class="form-control"
            id="JoiningDate" 
            value={joiningDate}
            placeholder="Joining Date"
            onChange={(e) => setJoiningDate(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="Project">Project</label>
            <input type="Project" 
            class="form-control"
            id="Project" 
            value={project}
            placeholder="Project"
            onChange={(e) => setProject(e.target.value)}
            />
        </div>

        {/* ============================= */}
        <button type="submit" class="btn btn-primary">Add</button>
        </form>
  </div>
)}