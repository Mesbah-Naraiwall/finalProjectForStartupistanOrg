import React, { useState, useEffect } from "react";
import axios from "axios";
import { useLocation, useNavigate, useParams } from "react-router-dom";
// import EmployeeData from './EmployeeData'
import moment from "moment";

// ==================================student data================
export default function AddEmp(){
const [nameOfStudent, setNameOfStudent] = useState('');
const [field, setField] = useState('');
const [commet, setCommet] = useState('');
const [image, setImage] = useState('');

const navigate = useNavigate();

// ===========================================add data =========================
const saveTestmonial = async (e) => {
    e.preventDefault();
    try{
    await axios.post(`http://localhost:4000/testmonial`,
    {
        nameOfStudent,
        field,
        commet,
        image,
    });
    navigate("/testmonialdata");
    } catch(error){
        console.log(error);
    }
  };
// ===========================
  return(
  <div className="container">
    <h1>Add Testmonial</h1>
    <form onSubmit={saveTestmonial}>
    <div className="form-group">
            <label for="nameOfStudent">Name Of Student</label>
            <input type="text" 
            class="form-control"
            value={nameOfStudent}
            id="nameOfStudent" 
            placeholder="nameOfStudent"
            onChange={(e) => setNameOfStudent(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="field">Field</label>
            <input type="text" 
            class="form-control"
            value={field}
            id="field" 
             placeholder="field"
            onChange={(e) => setField(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="commet">Comment</label>
            <input type="commet" 
            class="form-control"
            value={commet}
            id="commet" 
            placeholder="comment"
            onChange={(e) => setCommet(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">    
            <label for="image">Image Url</label>
            <input type="text" 
            class="form-control"
            value={image}
            id="image" 
            placeholder="image"
            onChange={(e) => setImage(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <button type="submit" class="btn btn-primary">Add</button>
        </form>
  </div>
)}