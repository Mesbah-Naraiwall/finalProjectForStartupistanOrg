import React, { useState, useEffect } from "react";
import axios from "axios";
import { useLocation, useNavigate, useParams } from "react-router-dom";

// ==================================contact data================
export default function UpdateTestMonail(userId){
const [nameOfStudent, setNameOfStudent] = useState('');
const [field, setField] = useState('');
const [commet, setCommet] = useState('');
const [image, setImage] = useState('');
const { _id } = useParams();

const state = useLocation().state;



const navigate = useNavigate();
// ==================================get data ================

useEffect(() => {
    getEmpById();
  }, []);

// ===========================================UPDATE data =========================
const getEmpById = async () => {
    const response = await axios.get(`http://localhost:4000/testmonial/${state._id}`);

    setNameOfStudent(response.data.nameOfStudent);
    setField(response.data.field);
    setCommet(response.data.commet);
    image(response.data.image);
  };
// ===========================
const updateTestmonial = async (e) => {
    e.preventDefault();
    try {
      await axios.patch(`http://localhost:4000/testmonial/${state._id}`, {
        nameOfStudent,
        field,
        commet,
        image,
      });
      navigate("/testmonaildata");
    } catch (error) {
      console.log(error);
    }
  };
  return(
  <div className="container">
    <h1>Update Contact</h1>
    <form onSubmit={updateTestmonial}>
    <div className="form-group">
            <label for="nameOfStudent">Name Of Student</label>
            <input type="text" 
            class="form-control"
            value={nameOfStudent}
            id="nameOfStudent" 
            placeholder="nameOfStudent"
            onChange={(e) => setNameOfStudent(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="field">Field</label>
            <input type="text" 
            class="form-control"
            value={field}
            id="field" 
             placeholder="Name"
            onChange={(e) => setField(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="commet">Comment</label>
            <input type="commet" 
            class="form-control"
            value={commet}
            id="commet" 
            placeholder="Email"
            onChange={(e) => setCommet(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="image">Image URL</label>
            <input type="text" 
            class="form-control"
            value={image}
            id="image" 
            placeholder="image"
            onChange={(e) => setImage(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <button type="submit" class="btn btn-success">Edit</button>
        </form>
  </div>
)}