import React, { useState, useEffect } from "react";
import axios from "axios";
import { useLocation, useNavigate, useParams } from "react-router-dom";

// ==================================contact data================
export default function UpdateTestMonail(userId){
const [aboutTitle, setAboutTitle] = useState('');
const [bodyPar, setBodyPar] = useState('');
const [coverImage, setCoverImage] = useState('');
const { _id } = useParams();

const state = useLocation().state;



const navigate = useNavigate();
// ==================================get data ================

useEffect(() => {
    getEmpById();
  }, []);

// ===========================================UPDATE data =========================
const getEmpById = async () => {
    const response = await axios.get(`http://localhost:4000/contactinfo/${state._id}`);

    setAboutTitle(response.data.aboutTitle);
    setBodyPar(response.data.bodyPar);
    coverImage(response.data.coverImage);
  };
// ===========================
const updateAbout = async (e) => {
    e.preventDefault();
    try {
      await axios.patch(`http://localhost:4000/contactinfo/${state._id}`, {
        aboutTitle,
        bodyPar,
        coverImage,
      });
      navigate("/aboutdata");
    } catch (error) {
      console.log(error);
    }
  };
  return(
  <div className="container">
    <h1>Update Contact</h1>
    <form onSubmit={updateAbout}>
    <div className="form-group">
            <label for="aboutTitle">About Title</label>
            <input type="text" 
            class="form-control"
            value={aboutTitle}
            id="aboutTitle" 
            placeholder="aboutTitle"
            onChange={(e) => setAboutTitle(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="bodyPar">Body Paragraph</label>
            <input type="text" 
            class="form-control"
            value={bodyPar}
            id="bodyPar" 
             placeholder="Body Paragraph"
            onChange={(e) => setBodyPar(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="coverImage">Image URL</label>
            <input type="text" 
            class="form-control"
            value={coverImage}
            id="coverImage" 
            placeholder="coverImage"
            onChange={(e) => setCoverImage(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <button type="submit" class="btn btn-success">Edit</button>
        </form>
  </div>
)}