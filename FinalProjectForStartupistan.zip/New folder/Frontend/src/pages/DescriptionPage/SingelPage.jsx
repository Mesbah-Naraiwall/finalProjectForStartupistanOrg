import React from "react";
import pic from '../../pages/course-2.jpg';
import { useState, useEffect } from "react";
import axios from "axios";
import {Link, useNavigate, useParams } from "react-router-dom";

export default function Register(){
    const [loading, setLoading] = useState(true);
    const [data, setData] = useState([])
    
    useEffect(() => {
      const fetchData = async () =>{
        setLoading(true);
        try {
          const {data: response} = await axios.get('http://localhost:4000/contactinfo');
          setData(response);
        } catch (error) {
          console.error(error.message);
        }
        setLoading(false);
      }
      fetchData();
    }, []);
    return(
        <div className="container-xxl py-5">
            <div className="container">
            <div className="row g-5">
                <div className="col-lg-6 wow fadeInUp" data-wow-delay="0.1s" style={{minHeight: "400px"}}>
                    <div className="position-relative h-100">
                        <img className="img-fluid position-absolute w-100 h-100" src={pic} alt="" style={{object_fit: "cover"}}/>
                    </div>
                </div>
                <div className="col-lg-6 wow fadeInUp" data-wow-delay="0.3s">
                    {data.map(item =>(<h6 className="section-title bg-white text-start text-primary pe-3">{item.aboutTitle}</h6>))}
                    <h1 className="mb-4"></h1>
                    {data.map(item =>(<p className="mb-4">{item.bodyPar}</p>))}
                </div>
            </div>
        </div>
            </div>
            )}