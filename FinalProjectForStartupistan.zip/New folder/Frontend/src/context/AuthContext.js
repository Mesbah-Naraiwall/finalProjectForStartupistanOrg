import { createContext, useState, useEffect } from "react";
import axios from "axios";
export const AuthContext = createContext()

export const AuthContextProvider = ({children})=>{

    const [currentUser, setCurrentUser] = useState(JSON.parse(localStorage.getItem("theUser"))|| null)
    // =======login function==========
    const signin = async (email, password)=>{
        const res =  await axios.post('http://localhost:4000/login',email, password)
        setCurrentUser(res.data)
    }

    // =========logout function==========
    const logout = async ()=>{
         await axios.post('http://localhost:4000/logout')
        setCurrentUser(null)
        alert('User Logout!')
    } 
    
    //=============use Effect Function==========
    useEffect(()=>{
        localStorage.setItem("theUser", JSON.stringify(currentUser))
    },[currentUser])
    return(<AuthContext.Provider value={{currentUser, signin, logout}}>
            {children}
          </AuthContext.Provider>
        )
}
