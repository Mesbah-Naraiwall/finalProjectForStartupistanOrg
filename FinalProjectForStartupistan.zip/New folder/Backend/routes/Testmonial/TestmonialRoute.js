const router = require("express").Router();
const mongoose = require('mongoose');
const Testmonial = require('../../models/Testmonial/testmonial')

// ==================Create New About=======================
router.post('/testmonial', async (req, res)=>{
    const {nameOfStudent, field, commet, image} = req.body;
    try{
        const testmonial = await Testmonial.create({nameOfStudent, field, commet, image})
        res.status(200).json(testmonial)
    }
    catch(error){
        res.status(400).json({error: error.message})
    }
})
// // ==================Show Single testmonials=======================
router.get('/testmonial/:id', async (req, res)=>{
    var testmonialId = req.params.id
    if(!mongoose.Types.ObjectId.isValid(testmonialId)){
        return res.status(404).json({erorr:"invalid Id Requisted"})
    }
    const testmonial = await Testmonial.findById(testmonialId)
    if(!testmonial){
        return res.status(404).json({error:"No testmonials by This id exsit!"})
    }
    res.status(200).json(testmonial)
})
// // ==================Show all testmonials=========================
router.get('/testmonial', async (req, res) => {
    const testmonials = await Testmonial.find({}).sort({createAt: -1})
    res.status(200).json(testmonials);
})

// // ==================Update a Single testmonials=================
router.patch('/testmonial/:id', async (req,res)=>{
    var testmonialId = req.params.id
    if(!mongoose.Types.ObjectId.isValid(testmonialId)){
        return res.status(404).json({erorr:"invalid Id Requisted"})
    }
    try{
        const testmonial  = await Testmonial.findById(testmonialId)
        if(testmonial.username === req.body.username){
            try{
                const updatatestmonial = await Testmonial.findByIdAndUpdate(testmonialId, {$set:req.body},{new:true})
                res.status(200).json(updatatestmonial)
            }catch(error){
                res.status(500).json(error)
            }
        }else{
            res.status(401).json({message:"you can update your testmonials Only!"})
        }
    }catch(error){
        res.status(500).json(error)
    }
})

// // ==================Delete A testmonials=======================
router.delete('/testmonial/:id', async (req, res)=>{
    var testmonialId = req.params.id
    if(!mongoose.Types.ObjectId.isValid(testmonialId)){
        return res.status(404).json({erorr:"invalid Id Requisted"})
    }
    try{
        const testmonials  = await Testmonial.findById(testmonialId)
        if(testmonials.username === req.body.username){
            try{
                await testmonials.delete()
                res.status(200).json({message:"testmonials Deleted!"})
            }catch(error){
                res.status(500).json(error)
            }
        }else{
            res.status(401).json({message:"you can Delete your testmonials Only!"})
        }
    }catch(erorr){
        res.status(500).json(erorr)
    }
})


module.exports = router