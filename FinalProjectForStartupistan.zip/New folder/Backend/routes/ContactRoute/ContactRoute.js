const router = require("express").Router();
const mongoose = require('mongoose');
const ContactInfo = require('../../models/Contact/contactInfo')

// ==================Create New About=======================
router.post('/contactinfo', async (req, res)=>{
    const {office, mobile, email, googleMap, aboutTitle, bodyPar, coverImage} = req.body;
    try{
        const newContactInfo = await ContactInfo.create({office, mobile, email, googleMap, aboutTitle, bodyPar, coverImage})
        res.status(200).json(newContactInfo)
    }
    catch(error){
        res.status(400).json({error: error.message})
    }
})
// // ==================Show Single contact=======================
router.get('/contactinfo/:id', async (req, res)=>{
    var contactId = req.params.id
    if(!mongoose.Types.ObjectId.isValid(contactId)){
        return res.status(404).json({erorr:"invalid Id Requisted"})
    }
    const contact = await ContactInfo.findById(contactId)
    if(!contact){
        return res.status(404).json({error:"No contact by This id exsit!"})
    }
    res.status(200).json(contact)
})
// // ==================Show all contact=========================
router.get('/contactinfo', async (req, res) => {
    const contacts = await ContactInfo.find({}).sort({createAt: -1})
    res.status(200).json(contacts);
})

// // ==================Update a Single contact=================
router.patch('/contactinfo/:id', async (req,res)=>{
    var contactId = req.params.id
    if(!mongoose.Types.ObjectId.isValid(contactId)){
        return res.status(404).json({erorr:"invalid Id Requisted"})
    }
    try{
        const contact  = await ContactInfo.findById(contactId)
        if(contact.username === req.body.username){
            try{
                const updatacontact = await ContactInfo.findByIdAndUpdate(contactId, {$set:req.body},{new:true})
                res.status(200).json(updatacontact)
            }catch(error){
                res.status(500).json(error)
            }
        }else{
            res.status(401).json({message:"you can update your contact Only!"})
        }
    }catch(error){
        res.status(500).json(error)
    }
})

// // ==================Delete A Contact=======================
router.delete('/contactinfo/:id', async (req, res)=>{
    var contactId = req.params.id
    if(!mongoose.Types.ObjectId.isValid(contactId)){
        return res.status(404).json({erorr:"invalid Id Requisted"})
    }
    try{
        const contact  = await ContactInfo.findById(contactId)
        if(contact.username === req.body.username){
            try{
                await contact.delete()
                res.status(200).json({message:"contact Deleted!"})
            }catch(error){
                res.status(500).json(error)
            }
        }else{
            res.status(401).json({message:"you can Delete your contact Only!"})
        }
    }catch(erorr){
        res.status(500).json(erorr)
    }
})


module.exports = router