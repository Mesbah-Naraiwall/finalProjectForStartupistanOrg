const router = require("express").Router();
const mongoose = require('mongoose');
const PopularCourse = require('../../models/Courses/popularCourses')

// ==================Create New About=======================
router.post('/popularcourse', async (req, res)=>{
    const {price, rating, nameOfCourse, instructor,desc, hours, studentMembers, image} = req.body;
    try{
        const course = await PopularCourse.create({price, rating, nameOfCourse, instructor,desc , hours, studentMembers, image})
        res.status(200).json(course)
    }
    catch(error){
        res.status(400).json({error: error.message})
    }
})
// // ==================Show Single courses=======================
router.get('/popularcourse/:id', async (req, res)=>{
    var courseId = req.params.id
    if(!mongoose.Types.ObjectId.isValid(courseId)){
        return res.status(404).json({erorr:"invalid Id Requisted"})
    }
    const course = await PopularCourse.findById(courseId)
    if(!course){
        return res.status(404).json({error:"No courses by This id exsit!"})
    }
    res.status(200).json(course)
})
// // ==================Show all courses=========================
router.get('/popularcourse', async (req, res) => {
    const courses = await PopularCourse.find({}).sort({createAt: -1})
    res.status(200).json(courses);
})

// // ==================Update a Single courses=================
router.patch('/popularcourse/:id', async (req,res)=>{
    var courseId = req.params.id
    if(!mongoose.Types.ObjectId.isValid(courseId)){
        return res.status(404).json({erorr:"invalid Id Requisted"})
    }
    try{
        const course  = await PopularCourse.findById(courseId)
        if(course.username === req.body.username){
            try{
                const updataCourse = await PopularCourse.findByIdAndUpdate(courseId, {$set:req.body},{new:true})
                res.status(200).json(updataCourse)
            }catch(error){
                res.status(500).json(error)
            }
        }else{
            res.status(401).json({message:"you can update your courses Only!"})
        }
    }catch(error){
        res.status(500).json(error)
    }
})

// // ==================Delete A courses=======================
router.delete('/popularcourse/:id', async (req, res)=>{
    var courseId = req.params.id
    if(!mongoose.Types.ObjectId.isValid(courseId)){
        return res.status(404).json({erorr:"invalid Id Requisted"})
    }
    try{
        const courses  = await PopularCourse.findById(courseId)
        if(courses.username === req.body.username){
            try{
                await courses.delete()
                res.status(200).json({message:"courses Deleted!"})
            }catch(error){
                res.status(500).json(error)
            }
        }else{
            res.status(401).json({message:"you can Delete your courses Only!"})
        }
    }catch(erorr){
        res.status(500).json(erorr)
    }
})


module.exports = router