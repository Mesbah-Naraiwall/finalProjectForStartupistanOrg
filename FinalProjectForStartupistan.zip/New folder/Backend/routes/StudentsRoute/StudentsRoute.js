const router = require("express").Router();
const mongoose = require('mongoose');
const Students = require('../../models/Students/students')

// ==================Create New About=======================
router.post('/student', async (req, res)=>{
    const {studnetId, name, fatherName, education, field, phone, email, batch, program, githubFinalProjectLink} = req.body;
    try{
        const student = await Students.create({studnetId, name, fatherName, education, field, phone, email, batch, program, githubFinalProjectLink})
        res.status(200).json(student)
    }
    catch(error){
        res.status(400).json({error: error.message})
    }
})
// // ==================Show Single students=======================
router.get('/student/:id', async (req, res)=>{
    var studentId = req.params.id
    if(!mongoose.Types.ObjectId.isValid(studentId)){
        return res.status(404).json({erorr:"invalid Id Requisted"})
    }
    const student = await Students.findById(studentId)
    if(!student){
        return res.status(404).json({error:"No students by This id exsit!"})
    }
    res.status(200).json(student)
})
// // ==================Show all students=========================
router.get('/student', async (req, res) => {
    const students = await Students.find({}).sort({createAt: -1})
    res.status(200).json(students);
})

// // ==================Update a Single students=================
router.patch('/student/:id', async (req,res)=>{
    var studentId = req.params.id
    if(!mongoose.Types.ObjectId.isValid(studentId)){
        return res.status(404).json({erorr:"invalid Id Requisted"})
    }
    try{
        const student  = await Students.findById(studentId)
        if(student.username === req.body.username){
            try{
                const updatastudent = await Students.findByIdAndUpdate(studentId, {$set:req.body},{new:true})
                res.status(200).json(updatastudent)
            }catch(error){
                res.status(500).json(error)
            }
        }else{
            res.status(401).json({message:"you can update your students Only!"})
        }
    }catch(error){
        res.status(500).json(error)
    }
})

// // ==================Delete A students=======================
router.delete('/student/:id', async (req, res)=>{
    var studentId = req.params.id
    if(!mongoose.Types.ObjectId.isValid(studentId)){
        return res.status(404).json({erorr:"invalid Id Requisted"})
    }
    try{
        const students  = await Students.findById(studentId)
        if(students.username === req.body.username){
            try{
                await students.delete()
                res.status(200).json({message:"students Deleted!"})
            }catch(error){
                res.status(500).json(error)
            }
        }else{
            res.status(401).json({message:"you can Delete your students Only!"})
        }
    }catch(erorr){
        res.status(500).json(erorr)
    }
})


module.exports = router