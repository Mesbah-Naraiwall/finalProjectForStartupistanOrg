const mongoose = require('mongoose')

const EmployeesSchema = mongoose.Schema({
    employeeId:{
        type: String,
        required: true
    },
    name:{
        type: String,
        required: true
    },
    position:{
        type: String,
        required: true
    }, 
    education:{
        type: String,
        required: true
    },
    joiningDate:{
        type: Date,
        required: true
    },
    contractDuration:{
        type: String,
        required: true
    },
    project:{
        type: String,
        required: true
    },
},{timestamps: true}) // it take automaticlly time 

module.exports = mongoose.model("Employees", EmployeesSchema)