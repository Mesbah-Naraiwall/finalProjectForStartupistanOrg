const mongoose = require('mongoose')

const PopularCoursesSchema = mongoose.Schema({
    price:{
        type: String,
        required: true
    },
    rating:{
        type: Number,
        required: true
    },
    nameOfCourse:{
        type: String,
        required: true
    },
    instructor:{
        type: String,
        required: true
    },
    desc:{
        type: String,
        required: true
    },
    hours:{
        type: Number,
        required: true
    },
    studentMembers:{
        type: Number,
        required: true
    },
    image:{
        type: String,
        required: true
    },
},{timestamps: true}) // it take automaticlly time 

module.exports = mongoose.model("popular course", PopularCoursesSchema)