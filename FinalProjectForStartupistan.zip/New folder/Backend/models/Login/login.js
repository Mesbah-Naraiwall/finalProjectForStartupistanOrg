const mongoose = require('mongoose')

const UsersSchema = mongoose.Schema({
    email: {
        type: String,
        required: [true, "Please provide an Email!"],
        unique: [true, "Email Exist"],
      },
      password: {
        type: String,
        required: [true, "Please provide a password!"],
        unique: false,
      },
},{timestamps: true}) // it take automaticlly time 

module.exports = mongoose.model("Users", UsersSchema)